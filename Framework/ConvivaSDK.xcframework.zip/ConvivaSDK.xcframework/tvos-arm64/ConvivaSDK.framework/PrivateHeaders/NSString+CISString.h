//
//  NSString+CISString.h
//  Pods
//
//  Created by Shubham Kumar Gupta on 20/01/25.
//

#import <Foundation/Foundation.h>

@interface NSString (CISString)

- (BOOL)isNilOrEmpty;
- (BOOL)isNotEmpty;

@end
