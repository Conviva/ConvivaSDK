//
//  CISBackgroundTask.h
//  Pods
//
//  Created by Shubham Kumar Gupta on 13/01/25.
//

#import <Foundation/Foundation.h>

@interface CISBackgroundTask : NSObject

- (void)startBackgroundTask;
- (void)endBackgroundTask;

@end
