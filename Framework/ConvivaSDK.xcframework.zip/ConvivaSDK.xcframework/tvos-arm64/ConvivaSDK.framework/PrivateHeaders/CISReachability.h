/*
 Copyright (c) 2011, Tony Million.
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 1. Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer.

 2. Redistributions in binary form must reproduce the above copyright notice,
 this list of conditions and the following disclaimer in the documentation
 and/or other materials provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.
 */

/*
 NOTE: This class and associated files were renamed from Reachability
 to CISReachability in order to avoid name conflicts.
 */

#import <SystemConfiguration/SystemConfiguration.h>

#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <netdb.h>
#import "CISLogger.h"

/**
 * Does ARC support support GCD objects?
 * It does if the minimum deployment target is iOS 6+ or Mac OS X 8+
 *
 * @see http://opensource.apple.com/source/libdispatch/libdispatch-228.18/os/object.h
 **/
#if OS_OBJECT_USE_OBJC
#define NEEDS_DISPATCH_RETAIN_RELEASE 0
#else
#define NEEDS_DISPATCH_RETAIN_RELEASE 1
#endif

extern NSString *const kCISReachabilityChangedNotification;

typedef enum {
    // Apple NetworkStatus Compatible Names.
    ConvivaNotReachable = 0,
    ConvivaReachableViaWWAN = 1,
    ConvivaReachableViaWiFi = 2,
    ConvivaReachableViaEthernet = 3
} ConvivaNetworkStatus;

@class CISReachability;

typedef void (^ConvivaNetworkReachable)(CISReachability *reachability);
typedef void (^ConvivaNetworkUnreachable)(CISReachability *reachability);

@interface CISReachability : NSObject

@property(nonatomic, copy) ConvivaNetworkReachable reachableBlock;
@property(nonatomic, copy) ConvivaNetworkUnreachable unreachableBlock;

@property(nonatomic, assign) BOOL reachableOnWWAN;

+ (CISReachability *)reachabilityWithHostname:(NSString *)hostname;
+ (CISReachability *)reachabilityForInternetConnection;
+ (CISReachability *)reachabilityWithAddress:(const struct sockaddr_in *)hostAddress;
+ (CISReachability *)reachabilityForLocalWiFi;

- (CISReachability *)init NS_UNAVAILABLE;
- (CISReachability *)initWithReachabilityRef:(SCNetworkReachabilityRef)ref NS_DESIGNATED_INITIALIZER;

- (BOOL)startNotifier;
- (void)stopNotifier;

- (BOOL)isReachable;
- (BOOL)isReachableViaWWAN;
- (BOOL)isReachableViaWiFi;

// WWAN may be available, but not active until a connection has been established.
// WiFi may require a connection for VPN on Demand.
- (BOOL)isConnectionRequired; // Identical DDG variant.
- (BOOL)connectionRequired;   // Apple's routine.
// Dynamic, on demand connection?
- (BOOL)isConnectionOnDemand;
// Is user intervention required?
- (BOOL)isInterventionRequired;

- (ConvivaNetworkStatus)currentReachabilityStatus;
- (SCNetworkReachabilityFlags)reachabilityFlags;
- (NSString *)currentReachabilityString;
- (NSString *)currentReachabilityFlags;

-(void)assignLogger:(CISLogger *)logger;
@end
